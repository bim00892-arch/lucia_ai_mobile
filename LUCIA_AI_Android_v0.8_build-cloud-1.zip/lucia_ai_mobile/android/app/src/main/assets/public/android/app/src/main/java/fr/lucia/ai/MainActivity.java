package fr.lucia.ai;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String PREFS = "lucia_secure_v1";
    private static final String ALIAS = "lucia_android_keystore_v1";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,13,24));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,13,24));
        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(false);
        ws.setAllowFileAccessFromFileURLs(false);
        ws.setAllowUniversalAccessFromFileURLs(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setSafeBrowsingEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the privileged JavaScript bridge on the bundled local app only.
                return !"file".equalsIgnoreCase(request.getUrl().getScheme());
            }
        });
        webView.addJavascriptInterface(new SecureVault(), "LuciaNativeVault");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/public/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        kg.init(new android.security.keystore.KeyGenParameterSpec.Builder(ALIAS,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build());
        return kg.generateKey();
    }

    private class SecureVault {
        @JavascriptInterface public String getItem(String key) {
            try {
                String packed = getSharedPreferences(PREFS, MODE_PRIVATE).getString(key, null);
                if (packed == null) return null;
                byte[] all = Base64.decode(packed, Base64.NO_WRAP);
                byte[] iv = java.util.Arrays.copyOfRange(all, 0, 12);
                byte[] ciphertext = java.util.Arrays.copyOfRange(all, 12, all.length);
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
                return new String(c.doFinal(ciphertext), StandardCharsets.UTF_8);
            } catch (Exception e) { return null; }
        }
        @JavascriptInterface public boolean setItem(String key, String value) {
            try {
                Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                c.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
                byte[] encrypted = c.doFinal(value.getBytes(StandardCharsets.UTF_8));
                byte[] iv = c.getIV();
                byte[] packed = new byte[iv.length + encrypted.length];
                System.arraycopy(iv, 0, packed, 0, iv.length);
                System.arraycopy(encrypted, 0, packed, iv.length, encrypted.length);
                return getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(key, Base64.encodeToString(packed, Base64.NO_WRAP)).commit();
            } catch (Exception e) { return false; }
        }
        @JavascriptInterface public boolean removeItem(String key) {
            return getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(key).commit();
        }
    }
}
